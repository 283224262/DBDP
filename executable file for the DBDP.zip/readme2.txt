This executable file has three parameters�� the path of input file, the path of output file, running time;
